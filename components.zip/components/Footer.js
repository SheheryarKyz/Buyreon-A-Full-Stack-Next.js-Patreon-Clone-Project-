import React from 'react'

const Footer = () => {
  return (
    <footer className=' bg-black text-white flex justify-center h-16 items-center px-4'>

      <p className="para text-center">Copyright &copy; Buyreon - Fund Your Projects With Crowdfunding - All rights reserved</p>
    </footer>
  )
}

export default Footer
