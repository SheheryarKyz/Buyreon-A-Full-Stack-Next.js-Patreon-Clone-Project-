"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useSession, signOut } from "next-auth/react";

const Navbar = () => {
  const { data: session } = useSession();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 z-50 w-full border-b border-white/10 bg-black text-white">
      <div className="flex h-18 w-full items-center justify-between px-8">
        {/* Logo */}
        <Link href="/" className="cursor-pointer">
          <div className="flex items-center">
            <Image
              src="/buyreon_B_minimal_gradient.gif"
              alt="Buyreon Logo"
              width={42}
              height={42}
            />

            <span className="ml-2 text-xl font-bold tracking-tight">
              Buyreon
            </span>
          </div>
        </Link>

        {/* Navigation */}
        <ul className="flex items-center gap-7 text-sm font-medium">
          {/* Home */}
          <li>
            <Link
              href="/"
              className="cursor-pointer transition-colors duration-200 hover:text-purple-400"
            >
              Home
            </Link>
          </li>

          {/* About */}
          <li>
            <Link
              href="/#discover-buyreon"
              className="cursor-pointer transition-colors duration-200 hover:text-purple-400"
            >
              About
            </Link>
          </li>

          {/* Projects */}
          <li>
            <Link href="/projects">
              <button className="cursor-pointer transition-colors duration-200 hover:text-purple-400">
                Projects
              </button>
            </Link>
          </li>

          {/* Authentication */}
          {session ? (
            /* Logged In */
            <li className="relative">
              {/* Welcome Dropdown Button */}
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="group inline-flex cursor-pointer items-center justify-center rounded-4xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500"
                type="button"
              >
                <span className="inline-flex items-center gap-2 rounded-4xl bg-black px-4 py-2 transition-all duration-200 group-hover:bg-transparent">
                  Welcome
                  <svg
                    className={`h-4 w-4 transition-transform duration-200 ${
                      isDropdownOpen ? "rotate-180" : ""
                    }`}
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m6 9 6 6 6-6"
                    />
                  </svg>
                </span>
              </button>

              {/* Dropdown Menu */}
              {isDropdownOpen && (
                <div className="absolute right-0 top-full z-10 mt-3 w-64 rounded-xl border border-white/10 bg-neutral-950 shadow-xl shadow-black/40">
                  {/* User Information */}
                  <div className="border-b border-white/10 px-4 py-4">
                    <p className="text-sm text-gray-400">Welcome</p>

                    <p className="mt-1 truncate text-sm font-medium text-white">
                      {session.user.email}
                    </p>
                  </div>

                  <div className="p-2">
                    {/* Dashboard */}
                    <Link
                      href="/dashboard"
                      onClick={() => setIsDropdownOpen(false)}
                      className="block w-full rounded-lg px-3 py-2 text-sm text-gray-300 transition-colors hover:bg-white/5 hover:text-white"
                    >
                      Dashboard
                    </Link>
                    {/* Your Page */}
                    <Link
                      href={`/${session.user.name}`}
                      onClick={() => setIsDropdownOpen(false)}
                      className="block w-full rounded-lg px-3 py-2 text-sm text-gray-300 transition-colors hover:bg-white/5 hover:text-white"
                    >
                      Your Page
                    </Link>

                    {/* Sign Out */}
                    <button
                      onClick={() => {
                        setIsDropdownOpen(false);
                        signOut(); //signOut({ callbackUrl: "/" });
                      }}
                      className="block w-full cursor-pointer rounded-lg px-3 py-2 text-left text-sm text-gray-300 transition-colors hover:bg-white/5 hover:text-red-400"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </li>
          ) : (
            /* Logged Out */
            <>
              {/* Login */}
              <li>
                <Link href="/login">
                  <button className="group inline-flex cursor-pointer items-center justify-center rounded-4xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <span className="rounded-4xl bg-black px-4 py-2 transition-all duration-200 group-hover:bg-transparent">
                      Login
                    </span>
                  </button>
                </Link>
              </li>

              {/* Sign Up */}
              <li>
                <Link href="/signup">
                  <button className="group inline-flex cursor-pointer items-center justify-center rounded-4xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <span className="rounded-4xl bg-black px-4 py-2 transition-all duration-200 group-hover:bg-transparent">
                      Sign Up
                    </span>
                  </button>
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
