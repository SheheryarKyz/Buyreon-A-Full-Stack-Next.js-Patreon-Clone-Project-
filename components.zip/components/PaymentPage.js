"use client";

import React from "react";
import { useForm } from "react-hook-form";
import { initiate } from "@/actions/useractions";

const PaymentPage = ({
  username,
  name,
  profilePicture,
  coverPicture,
  supporters,
}) => {
  const { register, getValues } = useForm();

  const pay = async (amount) => {
    const paymentform = getValues();

    const checkoutURL = await initiate(
      amount,
      username,
      paymentform
    );

    window.location.href = checkoutURL;
  };

  // Use database images if available.
  // Otherwise use the Ultramarines defaults.
  const creatorCoverPicture =
    coverPicture || "/ultramarine.png";

  const creatorProfilePicture =
    profilePicture || "/ultramarineprofpic.png";

  return (
    <>
      {/* Cover */}
      <div className="relative w-full">
        <div className="h-[350px] w-full overflow-hidden border-b border-white/10">
          <img
            src={creatorCoverPicture}
            alt="cover_picture"
            className="h-full w-full object-cover"
          />

          {/* Subtle overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10"></div>
        </div>

        {/* Profile Picture */}
        <div className="absolute left-1/2 -bottom-20 -translate-x-1/2 rounded-full bg-gradient-to-br from-purple-600 to-blue-500 p-1">
          <div className="rounded-full bg-black p-1">
            <img
              width={150}
              height={150}
              src={creatorProfilePicture}
              alt="profile_picture"
              className="h-[150px] w-[150px] rounded-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Creator Information */}
      <div className="mx-auto flex max-w-6xl flex-col items-center px-6 pt-28 text-center text-white">

        {/* Creator Name */}
        <h1 className="text-3xl font-bold tracking-tight md:text-4xl">
          {name || `@${username}`}
        </h1>

        {/* Username */}
        <p className="mt-2 text-sm text-gray-500">
          @{username}
        </p>

        {/* Description */}
        <p className="mt-3 max-w-xl text-sm text-gray-400 md:text-base">
          Creating animated art of the Warhammer 40k universe
        </p>

        {/* Stats */}
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3 text-sm text-gray-400">
          <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2">
            <span className="font-semibold text-white">
              9,721
            </span>{" "}
            members
          </div>

          <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2">
            <span className="font-semibold text-white">
              82
            </span>{" "}
            posts
          </div>

          <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2">
            <span className="font-semibold text-white">
              $15,450
            </span>{" "}
            / release
          </div>
        </div>

        {/* Payment Section */}
        <div className="mt-16 mb-20 grid w-full max-w-5xl gap-6 md:grid-cols-2">

          {/* Supporters */}
          <div className="rounded-2xl border border-white/10 bg-black/40 p-6 shadow-xl shadow-black/20 backdrop-blur-sm md:p-8">

            <div className="mb-6">
              <h2 className="text-2xl font-bold">
                Supporters
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                People supporting this creator
              </p>
            </div>

            <ul className="space-y-3 text-left">

              {supporters.length === 0 ? (
                <li className="rounded-xl border border-white/5 bg-white/5 p-4 text-center">
                  <p className="text-sm text-gray-500">
                    No supporters yet.
                  </p>
                </li>
              ) : (
                supporters.map((supporter, index) => (
                  <li
                    key={index}
                    className="rounded-xl border border-white/5 bg-white/5 p-4 transition-colors hover:bg-white/10"
                  >
                    <p className="text-sm text-gray-300">
                      {supporter.name} donated{" "}
                      <span className="font-bold text-white">
                        PKR {supporter.amount.toLocaleString()}
                      </span>
                    </p>

                    {supporter.message && (
                      <p className="mt-1 text-sm text-gray-500">
                        "{supporter.message}"
                      </p>
                    )}
                  </li>
                ))
              )}

            </ul>
          </div>

          {/* Make Payment */}
          <div className="rounded-2xl border border-white/10 bg-black/40 p-6 shadow-xl shadow-black/20 backdrop-blur-sm md:p-8">

            <div className="mb-6">
              <h2 className="text-2xl font-bold">
                Make a Payment
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                Support this creator's work
              </p>
            </div>

            <div className="flex flex-col gap-3">

              {/* Name */}
              <input
                {...register("name")}
                type="text"
                placeholder="Enter Name"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
              />

              {/* Message */}
              <input
                {...register("message")}
                type="text"
                placeholder="Enter Message"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
              />

              {/* Amount */}
              <input
                {...register("amount")}
                type="number"
                placeholder="Enter Amount"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
              />

              {/* Pay Button */}
              <button
                type="button"
                onClick={() => pay(getValues("amount"))}
                className="group mt-2 w-full cursor-pointer rounded-xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium"
              >
                <span className="block rounded-[10px] bg-black px-5 py-3 transition-all duration-200 group-hover:bg-transparent">
                  Pay
                </span>
              </button>

            </div>

            {/* Quick Payment */}
            <div className="mt-6">

              <p className="mb-3 text-left text-sm text-gray-500">
                Quick support
              </p>

              <div className="grid grid-cols-3 gap-2">

                <button
                  type="button"
                  onClick={() => pay(1000)}
                  className="cursor-pointer rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm font-medium text-gray-300 transition-all hover:border-purple-500/50 hover:bg-purple-500/10 hover:text-white"
                >
                  PKR 1,000
                </button>

                <button
                  type="button"
                  onClick={() => pay(2000)}
                  className="cursor-pointer rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm font-medium text-gray-300 transition-all hover:border-purple-500/50 hover:bg-purple-500/10 hover:text-white"
                >
                  PKR 2,000
                </button>

                <button
                  type="button"
                  onClick={() => pay(3000)}
                  className="cursor-pointer rounded-xl border border-white/10 bg-white/5 px-3 py-3 text-sm font-medium text-gray-300 transition-all hover:border-purple-500/50 hover:bg-purple-500/10 hover:text-white"
                >
                  PKR 3,000
                </button>

              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
};

export default PaymentPage;