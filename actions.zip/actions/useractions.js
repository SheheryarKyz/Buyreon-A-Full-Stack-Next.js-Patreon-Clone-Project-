"use server";

import connectDB from "@/db/connectDb";
import Payment from "@/models/Payment";
import User from "@/models/User";
import Safepay from "@sfpy/node-core";

export const initiate = async (amount, to_username, paymentform) => {
  await connectDB();

  // Find the creator who is receiving the payment
  const creator = await User.findOne({
    username: to_username,
  });

  if (!creator) {
    throw new Error("Creator not found");
  }

  // Make sure the creator has configured Safepay
  if (!creator.safepayPublicKey || !creator.safepaySecretKey) {
    throw new Error("This creator has not configured Safepay yet");
  }

  // Create Safepay using the creator's own credentials
  const safepay = new Safepay(creator.safepaySecretKey, {
    authType: "secret",
    host: "https://sandbox.api.getsafepay.com",
  });

  // Convert PKR to paisa
  // 1000 PKR = 100000 paisa
  const amountInPaisa = Number(amount) * 100;

  // Create payment session
  const response = await safepay.payments.session.setup({
    merchant_api_key: creator.safepayPublicKey,
    intent: "CYBERSOURCE",
    mode: "payment",
    entry_mode: "raw",
    currency: "PKR",
    amount: amountInPaisa,
  });

  const tracker = response.data.tracker;

  // Create authentication token
  const authResponse = await safepay.client.passport.create();

  const authToken = authResponse.data;

  // Create Safepay checkout URL
  const checkoutURL = safepay.checkout.createCheckoutUrl({
    tracker: tracker.token,
    tbt: authToken,
    env: "sandbox",
    source: "hosted",
    redirect_url: `${process.env.NEXT_PUBLIC_URL}/api/safepay`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/api/safepay`,
  });

  // Save payment information in MongoDB
  await Payment.create({
    oid: tracker.token,
    amount: Number(amount),
    to_user: to_username,
    name: paymentform.name,
    message: paymentform.message,
  });

  return checkoutURL;
};

export const fetchuser = async (username) => {
  await connectDB();

  const u = await User.findOne({
    username: username,
  });

  if (!u) {
    return null;
  }

  // Convert the Mongoose document into a plain object
  // and convert MongoDB ObjectIds into normal strings.
  const user = u.toObject({
    flattenObjectIds: true,
  });

  return user;
};

export const updateProfile = async (data, oldusername) => {
  await connectDB();

  // If the username is being changed,
  // check whether the new username is already taken.
  if (oldusername !== data.username) {
    const u = await User.findOne({
      username: data.username,
    });

    if (u) {
      return {
        error: "Username already exists",
      };
    }
  }

  const result = await User.updateOne(
    {
      email: data.email,
    },
    data
  );

  return {
    success: true,
    matched: result.matchedCount,
    modified: result.modifiedCount,
  };
};