import Image from "next/image";

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative flex min-h-[55vh] flex-col items-center justify-center overflow-hidden px-6 text-center text-white">

        {/* Background glow */}
        <div className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-purple-600/20 blur-3xl"></div>

        <div className="mb-5 flex items-center justify-center gap-3">
          <h1 className="text-5xl font-extrabold tracking-tight sm:text-6xl">
            Buyreon
          </h1>

          <Image
            src="/buyreon_B_minimal_gradient.gif"
            alt="Buyreon Logo"
            width={52}
            height={52}
          />
        </div>

        <p className="max-w-2xl text-base leading-7 text-gray-300 sm:text-lg">
          A crowdfunding platform for creators. Get funded by your fans and
          followers and turn your ideas into reality.
        </p>

        <div className="mt-8 flex flex-wrap justify-center gap-4">

          {/* Start Here */}
          <button className="group inline-flex cursor-pointer items-center justify-center rounded-4xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium text-white shadow-lg shadow-purple-900/20 transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300/30">
            <span className="rounded-4xl bg-neutral-950 px-6 py-3 transition-all duration-200 group-hover:bg-transparent">
              Start Here
            </span>
          </button>

          {/* Read More */}
          <button className="group inline-flex cursor-pointer items-center justify-center rounded-4xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium text-white shadow-lg shadow-purple-900/20 transition-transform duration-200 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300/30">
            <span className="rounded-4xl bg-neutral-950 px-6 py-3 transition-all duration-200 group-hover:bg-transparent">
              Read More
            </span>
          </button>

        </div>
      </section>

      {/* Divider */}
      <div className="h-px w-full bg-white/10"></div>

      {/* Support Section */}
      <section className="container mx-auto px-6 pb-32 pt-20 text-white">

        <div className="mb-14 text-center">
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-purple-400">
            Built for creators
          </p>

          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Your Fans Can Support Your Projects
          </h2>

          <p className="mx-auto mt-4 max-w-2xl text-gray-400">
            Turn your audience into a community that helps you bring your
            creative projects and ideas to life.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">

          {/* Card 1 */}
          <div className="group flex flex-col items-center rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center transition-all duration-300 hover:-translate-y-1 hover:border-purple-500/30 hover:bg-white/[0.05]">

            <div className="mb-6 rounded-full bg-purple-950/70 p-3 ring-1 ring-purple-500/20">
              <Image
                width={130}
                height={130}
                src="/avedeto-pixel-art-12601.gif"
                alt="Man working"
                className="rounded-full p-4"
              />
            </div>

            <h3 className="text-lg font-bold">
              Fans Want to Help
            </h3>

            <p className="mt-3 text-sm leading-6 text-gray-400">
              Your fans can support the work you create and help you continue
              doing what you love.
            </p>
          </div>

          {/* Card 2 */}
          <div className="group flex flex-col items-center rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center transition-all duration-300 hover:-translate-y-1 hover:border-purple-500/30 hover:bg-white/[0.05]">

            <div className="mb-6 rounded-full bg-purple-950/70 p-3 ring-1 ring-purple-500/20">
              <Image
                width={130}
                height={130}
                src="/pikura-coin-20749.gif"
                alt="Coin"
                className="rounded-full p-4"
              />
            </div>

            <h3 className="text-lg font-bold">
              Turn Support Into Funding
            </h3>

            <p className="mt-3 text-sm leading-6 text-gray-400">
              Receive financial support from your community and put it toward
              your next big project.
            </p>
          </div>

          {/* Card 3 */}
          <div className="group flex flex-col items-center rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center transition-all duration-300 hover:-translate-y-1 hover:border-purple-500/30 hover:bg-white/[0.05]">

            <div className="mb-6 rounded-full bg-purple-950/70 p-3 ring-1 ring-purple-500/20">
              <Image
                width={130}
                height={130}
                src="/mxj_files-dancing-13955_512.gif"
                alt="Group of people"
                className="rounded-full p-4"
              />
            </div>

            <h3 className="text-lg font-bold">
              Build Your Community
            </h3>

            <p className="mt-3 text-sm leading-6 text-gray-400">
              Create a community around your work and grow together with the
              people who believe in your ideas.
            </p>
          </div>

        </div>
      </section>

      {/* Divider */}
      <div className="h-px w-full bg-white/10"></div>

      {/* About Us Section */}
<section
  id="discover-buyreon"
  className="container mx-auto flex flex-col items-center px-6 pb-32 pt-20 text-white"
>

        <div className="mb-12 text-center">
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-purple-400">
            Discover Buyreon
          </p>

          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Learn More About Us
          </h2>

          <p className="mx-auto mt-4 max-w-2xl text-gray-400">
            Learn more about Buyreon and how we're helping creators connect
            with their supporters.
          </p>
        </div>

        {/* Video */}
        <div className="w-full max-w-4xl overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-2 shadow-2xl shadow-purple-950/20">
          <div className="aspect-video w-full overflow-hidden rounded-xl">
            <iframe
              className="h-full w-full"
              src="https://www.youtube.com/embed/bHEZ6yQK6Lw?si=XGZDaUi2WW0EWBsK"
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            ></iframe>
          </div>
        </div>

      </section>
    </>
  );
}