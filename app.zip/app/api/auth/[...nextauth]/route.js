import NextAuth from 'next-auth'
import AppleProvider from 'next-auth/providers/apple'
import FacebookProvider from 'next-auth/providers/facebook'
import GoogleProvider from 'next-auth/providers/google'
import EmailProvider from 'next-auth/providers/email'
import GitHubProvider from "next-auth/providers/github";
import User from '@/models/User';
import connectDB from '@/db/connectDb';

export const authoptions = NextAuth({
  providers: [
    // OAuth authentication providers...
    GitHubProvider({
      clientId: process.env.GITHUB_ID,
      clientSecret: process.env.GITHUB_SECRET
    }),

    // AppleProvider({
    //   clientId: process.env.APPLE_ID,
    //   clientSecret: process.env.APPLE_SECRET
    // }),

    // FacebookProvider({
    //   clientId: process.env.FACEBOOK_ID,
    //   clientSecret: process.env.FACEBOOK_SECRET
    // }),

    // GoogleProvider({
    //   clientId: process.env.GOOGLE_ID,
    //   clientSecret: process.env.GOOGLE_SECRET
    // }),

    // EmailProvider({
    //   server: process.env.MAIL_SERVER,
    //   from: 'NextAuth.js <no-reply@example.com>'
    // }),
  ],

  callbacks: {

    async signIn({ user, account, profile, email, credentials }) {

      console.log("SIGN IN CALLBACK RUNNING");
      console.log("GitHub user:", user);

      if (account.provider === "github") {
        console.log("Connecting to MongoDB...");

        await connectDB();

        console.log("MongoDB connection finished");
      }

      // check if user exists in the database
      const currentUser = await User.findOne({
        email: user.email
      });

      console.log("Current user:", currentUser);

      if (!currentUser) {

        console.log("User doesn't exist. Creating user...");

        // create a new user
        const newUser = new User({
          email: user.email,
          username: user.email.split("@")[0],
        });

        await newUser.save();

        console.log("New user saved:", newUser);
      }

      return true;
    },

    async session({ session, user, token }) {

      const dbUser = await User.findOne({
        email: session.user.email
      });

      session.user.name = dbUser.username;

      return session;
    },
  },
})

export { authoptions as GET, authoptions as POST }