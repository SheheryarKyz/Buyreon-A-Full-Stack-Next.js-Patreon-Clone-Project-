import { NextResponse } from "next/server";
import connectDB from "@/db/connectDb";
import Payment from "@/models/Payment";
import Safepay from "@sfpy/node-core";

export async function GET(request) {

  await connectDB();

  // Get tracker from Safepay redirect URL
  const { searchParams } = new URL(request.url);
  const tracker = searchParams.get("tracker");

  console.log("Safepay tracker:", tracker);

  if (!tracker) {
    return NextResponse.json(
      {
        success: false,
        message: "Tracker not found",
      },
      { status: 400 }
    );
  }

  // Connect to Safepay
  const safepay = new Safepay(process.env.SAFEPAY_SECRET_KEY, {
    authType: "secret",
    host: "https://sandbox.api.getsafepay.com",
  });

  // Get payment status from Safepay
  const response = await safepay.reporter.payments.fetch(tracker);

  console.log("Safepay payment response:", response);

  // Check whether the payment was completed
  const paymentState = response.data?.state;

  if (paymentState === "TRACKER_ENDED") {

    // Mark payment as completed in MongoDB
    const updatedPayment = await Payment.findOneAndUpdate(
      { oid: tracker },
      { done: true },
      { new: true }
    );

    if (!updatedPayment) {
      return NextResponse.json(
        {
          success: false,
          message: "Payment not found in database",
        },
        { status: 404 }
      );
    }

    console.log("Payment marked as completed:", updatedPayment);

    // Redirect back to the creator's page
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_URL}/${updatedPayment.to_user}?paymentdone=true`
    );
  }

  // Payment was not completed
  return NextResponse.redirect(
    `${process.env.NEXT_PUBLIC_URL}/?paymentdone=false`
  );
}