"use client";

import React, { useEffect, useRef } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { fetchuser, updateProfile } from "@/actions/useractions";

const Dashboard = () => {
  const { data: session } = useSession();
  const router = useRouter();

  // Used to prevent the database-loading effect from
  // immediately putting the saved values back into the form.
  const justSaved = useRef(false);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { isSubmitting },
  } = useForm({
    defaultValues: {
      name: "",
      email: "",
      username: "",
      profilePicture: "",
      coverPicture: "",
      safepayPublicKey: "",
      safepaySecretKey: "",
    },
  });

  useEffect(() => {
    if (!session) {
      router.push("/login");
    }
  }, [session, router]);

  // Get existing user data from MongoDB
  useEffect(() => {
    const getData = async () => {
      if (session?.user?.name) {

        // Don't reload the saved data immediately after
        // we have intentionally cleared the form.
        if (justSaved.current) {
          justSaved.current = false;
          return;
        }

        const user = await fetchuser(session.user.name);

        if (user) {
          setValue("name", user.name || "");
          setValue("email", user.email || "");
          setValue("username", user.username || "");
          setValue("profilePicture", user.profilePicture || "");
          setValue("coverPicture", user.coverPicture || "");
          setValue("safepayPublicKey", user.safepayPublicKey || "");
          setValue("safepaySecretKey", user.safepaySecretKey || "");
        }
      }
    };

    getData();
  }, [session, setValue]);

  // Save changes
  const onSubmit = async (data) => {
    const result = await updateProfile(
      data,
      session.user.name
    );

    if (result?.error) {
      alert(result.error);
      return;
    }

    // Tell the fetch effect that the form has just been saved.
    justSaved.current = true;

    // Clear all fields.
    reset({
      name: "",
      email: "",
      username: "",
      profilePicture: "",
      coverPicture: "",
      safepayPublicKey: "",
      safepaySecretKey: "",
    });

    alert("Profile Updated");

    // If username was changed, go to the new profile page.
    if (data.username !== session.user.name) {
      router.push(`/${data.username}`);
    }
  };

  return (
    <main className="relative overflow-hidden px-4 py-14 text-white">

      {/* Background Glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-[-250px] h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-purple-600/10 blur-[140px]" />

        <div className="absolute bottom-[-250px] left-1/2 h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-blue-600/10 blur-[140px]" />
      </div>

      <div className="relative mx-auto max-w-5xl">

        {/* Header */}
        <div className="mb-10 text-center">

          <div className="mb-4 inline-flex items-center rounded-full border border-purple-500/20 bg-purple-500/5 px-4 py-1.5 text-xs font-medium text-purple-300">
            Creator Dashboard
          </div>

          <h1 className="text-3xl font-bold tracking-tight md:text-4xl">
            Welcome to your Dashboard
          </h1>

          <p className="mx-auto mt-3 max-w-lg text-sm leading-6 text-gray-400">
            Manage your creator profile and payment information from one place.
          </p>

        </div>

        {/* Main Card */}
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-black/50 shadow-2xl shadow-black/30 backdrop-blur-xl">

          <form onSubmit={handleSubmit(onSubmit)}>

            {/* Creator Profile */}
            <div className="p-6 md:p-8">

              <div className="mb-7 flex items-center gap-4">

                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-linear-to-br from-purple-600 to-blue-500 text-sm font-bold">
                  01
                </div>

                <div>
                  <h2 className="font-semibold">
                    Creator Profile
                  </h2>

                  <p className="mt-0.5 text-xs text-gray-500">
                    Tell your supporters about yourself
                  </p>
                </div>

              </div>

              <div className="grid gap-5 md:grid-cols-2">

                {/* Name */}
                <div>
                  <label
                    htmlFor="name"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Name
                  </label>

                  <input
                    id="name"
                    type="text"
                    placeholder="Enter your name"
                    {...register("name")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

                {/* Email */}
                <div>
                  <label
                    htmlFor="email"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Email
                  </label>

                  <input
                    id="email"
                    type="email"
                    {...register("email")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

                {/* Username */}
                <div>
                  <label
                    htmlFor="username"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Username
                  </label>

                  <input
                    id="username"
                    type="text"
                    placeholder="Choose your username"
                    {...register("username")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

                {/* Profile Picture */}
                <div>
                  <label
                    htmlFor="profilePicture"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Profile Picture URL
                  </label>

                  <input
                    id="profilePicture"
                    type="text"
                    placeholder="Enter profile picture URL"
                    {...register("profilePicture")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

                {/* Cover Picture */}
                <div className="md:col-span-2">
                  <label
                    htmlFor="coverPicture"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Cover Picture URL
                  </label>

                  <input
                    id="coverPicture"
                    type="text"
                    placeholder="Enter cover picture URL"
                    {...register("coverPicture")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

              </div>
            </div>

            {/* Divider */}
            <div className="h-px bg-white/10" />

            {/* Payment Settings */}
            <div className="p-6 md:p-8">

              <div className="mb-7 flex items-center gap-4">

                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-linear-to-br from-purple-600 to-blue-500 text-sm font-bold">
                  02
                </div>

                <div>
                  <h2 className="font-semibold">
                    Payment Settings
                  </h2>

                  <p className="mt-0.5 text-xs text-gray-500">
                    Connect your Safepay account
                  </p>
                </div>

              </div>

              <div className="grid gap-5 md:grid-cols-2">

                {/* Public Key */}
                <div>
                  <label
                    htmlFor="safepayPublicKey"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Safepay Public Key
                  </label>

                  <input
                    id="safepayPublicKey"
                    type="text"
                    placeholder="Enter your public key"
                    {...register("safepayPublicKey")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

                {/* Secret Key */}
                <div>
                  <label
                    htmlFor="safepaySecretKey"
                    className="mb-2 block text-sm font-medium text-gray-300"
                  >
                    Safepay Secret Key
                  </label>

                  <input
                    id="safepaySecretKey"
                    type="password"
                    placeholder="Enter your secret key"
                    {...register("safepaySecretKey")}
                    className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-gray-600 hover:border-white/20 focus:border-purple-500 focus:bg-white/[0.05] focus:ring-2 focus:ring-purple-500/10"
                  />
                </div>

              </div>

              {/* Security Notice */}
              <div className="mt-5 rounded-xl border border-purple-500/10 bg-purple-500/[0.03] px-4 py-3">
                <p className="text-xs leading-5 text-gray-500">
                  Your Safepay credentials are used to process payments for
                  your creator account. Keep your secret key private.
                </p>
              </div>

            </div>

            {/* Save Area */}
            <div className="border-t border-white/10 bg-white/[0.02] px-6 py-5 md:px-8">

              <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">

                <p className="text-xs text-gray-500">
                  Changes will be saved to your creator profile.
                </p>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group w-full cursor-pointer rounded-xl bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
                >
                  <span className="flex min-w-[150px] items-center justify-center rounded-[10px] bg-black px-6 py-3 transition-all duration-200 group-hover:bg-transparent">
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </span>
                </button>

              </div>

            </div>

          </form>
        </div>

      </div>
    </main>
  );
};

export default Dashboard;