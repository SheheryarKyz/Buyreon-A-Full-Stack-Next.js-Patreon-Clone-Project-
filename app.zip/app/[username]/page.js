import React from "react";
import PaymentPage from "@/components/PaymentPage";
import connectDB from "@/db/connectDb";
import Payment from "@/models/Payment";
import User from "@/models/User";

const Username = async ({ params }) => {
  const { username } = await params;

  // Connect to MongoDB
  await connectDB();

  // Get creator information
  const user = await User.findOne({
    username: username,
  }).lean();

  // Creator doesn't exist
  if (!user) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center px-6 text-center text-white">
        <div>
          <h1 className="text-3xl font-bold">
            Creator Not Found
          </h1>

          <p className="mt-3 text-gray-400">
            The creator you are looking for does not exist.
          </p>
        </div>
      </div>
    );
  }

  // Get all completed payments made to this creator
  const payments = await Payment.find({
    to_user: username,
    done: true,
  })
    .sort({ createdAt: -1 })
    .lean();

  // Send only the data that PaymentPage needs
  const supporters = payments.map((payment) => ({
    name: payment.name,
    amount: payment.amount,
    message: payment.message,
  }));

  return (
    <PaymentPage
      username={username}
      name={user.name}
      profilePicture={user.profilePicture}
      coverPicture={user.coverPicture}
      supporters={supporters}
    />
  );
};

export default Username;