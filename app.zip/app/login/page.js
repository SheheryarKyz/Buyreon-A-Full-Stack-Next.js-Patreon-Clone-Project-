"use client";

import Image from "next/image";
import { useForm } from "react-hook-form";
import { useSession, signIn, signOut } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect } from "react";


const Login = () => {
const { data: session } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (session) {
      router.push("/dashboard");
    }
  }, [session, router]);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm();

  const onSubmit = async (data) => {
    console.log(data);
  };

  return (
    <div className="container mx-auto px-4 py-14 text-white">
      <h1 className="text-center text-3xl font-bold">
        Login to get your Fans to support you
      </h1>

      <div className="mx-auto mt-10 flex max-w-md flex-col gap-3">

        {/* Email & Password Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">

          {/* Email */}
          <div className="flex flex-col gap-2">
            <label htmlFor="email" className="text-sm font-medium">
              Email
            </label>

            <input
              id="email"
              type="email"
              placeholder="Enter your email"
              className="rounded-lg border border-white/10 bg-neutral-950 px-4 py-3 text-white outline-none transition-all duration-200 placeholder:text-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
              {...register("email", {
                required: "Email is required",
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: "Please enter a valid email address",
                },
              })}
            />

            {errors.email && (
              <p className="text-sm text-red-400">
                {errors.email.message}
              </p>
            )}
          </div>

          {/* Password */}
          <div className="flex flex-col gap-2">
            <label htmlFor="password" className="text-sm font-medium">
              Password
            </label>

            <input
              id="password"
              type="password"
              placeholder="Enter your password"
              className="rounded-lg border border-white/10 bg-neutral-950 px-4 py-3 text-white outline-none transition-all duration-200 placeholder:text-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
              {...register("password", {
                required: "Password is required",
                minLength: {
                  value: 6,
                  message: "Password must be at least 6 characters",
                },
              })}
            />

            {errors.password && (
              <p className="text-sm text-red-400">
                {errors.password.message}
              </p>
            )}
          </div>

          {/* Login Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="group inline-flex w-full cursor-pointer items-center justify-center rounded-lg bg-linear-to-br from-purple-600 to-blue-500 p-0.5 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            <span className="w-full rounded-md bg-neutral-950 px-5 py-3 transition-all duration-200 group-hover:bg-transparent">
              {isSubmitting ? "Logging in..." : "Login"}
            </span>
          </button>
        </form>

        {/* Divider */}
        <div className="my-4 flex items-center gap-3">
          <div className="h-px flex-1 bg-white/10"></div>
          <span className="text-sm text-gray-500">OR</span>
          <div className="h-px flex-1 bg-white/10"></div>
        </div>

        {/* Google */}
        <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/475656/google-color.svg"
            width={20}
            height={20}
            alt="Google"
          />
          <span>Continue with Google</span>
        </button>

        {/* LinkedIn */}
        <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/448234/linkedin.svg"
            width={20}
            height={20}
            alt="LinkedIn"
          />
          <span>Continue with LinkedIn</span>
        </button>

        {/* Twitter */}
        <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/521900/twitter.svg"
            width={20}
            height={20}
            alt="Twitter"
          />
          <span>Continue with Twitter</span>
        </button>

        {/* Facebook */}
        <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/452196/facebook-1.svg"
            width={20}
            height={20}
            alt="Facebook"
          />
          <span>Continue with Facebook</span>
        </button>

        {/* GitHub */}
        <button onClick={()=>{signIn("github")}} className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/512317/github-142.svg"
            width={20}
            height={20}
            alt="GitHub"
          />
          <span>Continue with GitHub</span>
        </button>

        {/* Apple */}
        <button className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-lg border border-white/10 bg-white px-5 py-3 text-sm font-medium text-black transition-all duration-200 hover:border-white/20 hover:bg-linear-to-br hover:from-purple-600 hover:to-blue-500 hover:text-white">
          <Image
            src="https://www.svgrepo.com/show/511330/apple-173.svg"
            width={20}
            height={20}
            alt="Apple"
          />
          <span>Continue with Apple</span>
        </button>

      </div>
    </div>
  );
};

export default Login;