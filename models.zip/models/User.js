import mongoose from "mongoose";

const { Schema, model } = mongoose;

const UserSchema = new Schema({

  email: {
    type: String,
    required: true,
    unique: true
  },

  name: {
    type: String
  },

  username: {
    type: String,
    required: true
  },

  profilePicture: {
    type: String
  },

  coverPicture: {
    type: String
  },

  safepayPublicKey: {
    type: String
  },

  safepaySecretKey: {
    type: String
  },

  createdAt: {
    type: Date,
    default: Date.now
  },

  updateAt: {
    type: Date,
    default: Date.now
  },

});

export default mongoose.models.User || model("User", UserSchema);